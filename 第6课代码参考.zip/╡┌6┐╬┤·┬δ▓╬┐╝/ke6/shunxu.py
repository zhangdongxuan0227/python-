# coding:utf-8
import unittest

class Test(unittest.TestCase):

    def test_01(self):
        print("测试用例01----------01")

    def test_1(self):
        print("测试用例1----------1")

    def test_AAA(self):
        print("测试用例AAA----------AAA")

    def test_aaaa(self):
        print("测试用例aaaa----------aaaa")

    def test_BBB(self):
        print("测试用例BBB----------BBB")

    def test_03(self):
        print("测试用例03----------03")

    def test_02(self):
        print("测试用例02----------02")

if __name__ == "__main__":
    unittest.main()